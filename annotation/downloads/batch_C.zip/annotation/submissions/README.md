Save work in <reviewer_id>/batches/<A|B|C>/. All reviewers process the same round independently, then compare. Preserve original drafts and actual human review notes.
