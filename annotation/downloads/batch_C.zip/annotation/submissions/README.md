Create your own reviewer folder; keep original LLM drafts and human reviews separately.
